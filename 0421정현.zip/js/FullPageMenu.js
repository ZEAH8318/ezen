console.clear();

const { gsap } = window;

const btn = document.querySelector(".menu-btn");
const nav = document.querySelector(".nav");

btn.addEventListener("click", () => {
	if (btn.classList.contains("active")) {
		btn.classList.remove("active");
		hide();
	} else {
		btn.classList.add("active");
		show().stop();	
	}
});

function show() {
	let tl = gsap.timeline();

	gsap.set(".nav__inner, .menu-btn", {
		pointerEvents: "none"
	});

	tl.set(".nav__inner", {
		zIndex: 9999
	})
	.fromTo(
		".nav--transition-slide",
		{
			scaleX: 0,
			transformOrigin: "left center",
		},
		{
			duration: 0.5,
			scaleX: 1,
			ease: "Expo.inOut",
		}
	)
	.set(".nav__inner, .menu-btn", {
		pointerEvents: "all",
	})
	.fromTo(
		".nav--item-line",
		{
			scaleX: 0,
			transformOrigin: "left center",
		},
		{
			duration: 0.65,
			scaleX: 1,
			ease: "Expo.inOut",
			stagger: 0.15,
		}
	)
	.fromTo(
		".nav--link",
		{
			translateY: "100%",
		},
		{
			duration: 2.25,
			translateY: 0,
			ease: "elastic.inOut",
			stagger: 0.15,
		},
		"-=1.65"
	);
	nav.style.cssText="z-index: 9998;"

}

function hide() {
	let tl = gsap.timeline();

	gsap.set(".nav__inner, .menu-btn", {
		pointerEvents: "none",
	});

	tl.to(".nav--item-line", {
		duration: 0.6,
		scaleX: 0,
		transformOrigin: "right center",
		ease: "Expo.inOut",
		stagger: -0.15,
	})
	.to(
		".nav--link",
		{
			duration: 0.35,
			translateY: "100%",
			ease: "Expo.inOut",
			stagger: -0.15,
		},
		0
	)
	.to(".nav--transition-slide", {
		duration: 0.5,
		transformOrigin: "right center",
		scaleX: 0,
		ease: "Expo.inOut",
	})

	.set(" .menu-btn", {
		pointerEvents: "all",
	})
	.set(".nav__inner", {
		zIndex: -1
	});
	nav.style.cssText="display : none;"
}