<script>
function checkReservation() {
  const name = document.getElementById('name').value;
  const adults = document.getElementById('adults').value;
  const children = document.getElementById('children').value;
  const infants = document.getElementById('infants').value;
  const date = document.getElementById('date').value;
  const startTime = document.getElementById('start-time').value;
  const endTime = document.getElementById('end-time').value;

  // 예약 확인 로직 구현 (생략)

  // 팝업 생성
  const popup = window.open('', 'reservation-check', 'width=500,height=500');
  popup.document.write(`
    <h2>예약 조회 결과</h2>
    <p>성함: ${name}</p>
    <p>성인: ${adults}</p>
    <p>어린이: ${children}</p>
    <p>유아: ${infants}</p>
    <p>예약날짜: ${date}</p>
    <p>이용시간: ${startTime} - ${endTime}</p>
    <p>방문시간: ${visitTime}</p>
    <button onclick="window.close()">X</button>
  `);
}

document.getElementById('chk_res_chk').addEventListener('click', checkReservation);
</script>