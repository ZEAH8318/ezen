	    function decrease(id) {
			var num = document.getElementById(id).value;
			if (num > 0) {
				num--;
			}
			document.getElementById(id).value = num;
		}
		
		function increase(id) {
			var num = document.getElementById(id).value;
			num++;
			document.getElementById(id).value = num;
		}
		
		function check() {
			var adult = document.getElementById("adult").value;
			var child = document.getElementById("child").value;
			var infant = document.getElementById("infant").value;
			var total = parseInt(adult) + parseInt(child) + parseInt(infant);
			alert("성인: " + adult + ", 어린이: " + child + ", 유아: " + infant + ", 총 인원: " + total);
		}